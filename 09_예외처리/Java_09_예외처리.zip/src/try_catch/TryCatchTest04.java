package try_catch;

public class TryCatchTest04 {
	public static void main(String[] args) {
		// 발생할 수 있는 예외가 여러개라면?
		int[] nums = { 10 };

		try {
			System.out.println("정상 수행 코드1");
			System.out.println(nums[10]); // 예외가 발생할 수도 있는 코드!
			System.out.println("정상 수행 코드2");
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("인덱스 에러 발생!");
			return; //어떤 상황에서 예외처리 후 해당 메서드를 종료하고 싶어!
		} finally {
			System.out.println("무조건 수행하는 코드");
		}
		//파이널리에 들어갈 내용이 있으면 되겠지요.
//		return;
		System.out.println("프로그램 종료");
	}
}
