package throws_test;

//UnChecked 계열
public class ThrowsTest02 {
	public static void main(String[] args) {
		try {
			method1();
		}catch (ArithmeticException e) {
			System.out.println("수학적 이슈 발생");
		}
	}

	// ,를 이용하여 여러개의 예외를 던질 수도 있다.
	public static void method1() {
		// 처리할래? 말래?
		method2();
	}

	public static void method2()  {
		// UnChecked 계열을 발생시키자!
		// 1. 직접 처리하는 방식
		// 2. 간접 처리하는 방식 -> 나를 호출한 곳으로 던져(위임)
		int i = 1/0; //아주 심플하게 런타임계열에 이슈를 발생시킴
	}
}
