package throws_test;

//Checked 계열
public class ThrowsTest01 {
	//메인에서도 던질 수 있지만 그건 처리안한 것과 똑같아!
//	public static void main(String[] args) throws ClassNotFoundException{
//		method1();
//	}
	public static void main(String[] args){
		try {
			method1();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	//,를 이용하여 여러개의 예외를 던질 수도 있다.
	public static void method1() throws ClassNotFoundException, ArrayIndexOutOfBoundsException {
		//처리할래? 말래?
		method2();
	}

	public static void method2() throws ClassNotFoundException {
		//Checked 계열을 발생시키자!
		//1. 직접 처리하는 방식
		//2. 간접 처리하는 방식 -> 나를 호출한 곳으로 던져(위임)
		Class.forName(null);
	}
}
