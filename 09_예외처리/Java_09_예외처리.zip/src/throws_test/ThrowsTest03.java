package throws_test;

import java.io.FileNotFoundException;
import java.io.IOException;

class Parent {
	void method1() throws IOException {
		// 코드가 블라블라
	}

	void method2() throws ClassNotFoundException {
		// 코드가 블라블라
	}
}

class Child extends Parent {
	@Override
	void method1() throws FileNotFoundException {
		// 코드가 블라블라
	}
//	@Override
//	void method2() throws Exception {
//		//코드가 블라블라
//      //자식은 부모보다 더 큰 예외를 던질 수 없어요.
//	}
}

public class ThrowsTest03 {
	public static void main(String[] args) {
		Parent p = new Child();

//		p.method1();

	}

}
