package exception_user;

public class UserExceptionTest {
	public static String[] fruits = {"두리안", "딸기", "복숭아","수박"};
	
	public static void main(String[] args) {
//		try {
//			sell("딸기");
//			sell("개살구");
//		} catch (FruitNotFoundException e) {
//			e.printStackTrace();
//		}
		try {
			sell2("딸기");
			sell2("개살구");
		} catch (FruitNotFoundRuntimeException e) {
			System.out.println("판매실패");
		}
	}
	
	//과일을 판매해보자
//	public static void sell(String name) throws FruitNotFoundException {
//		//과일 목록 전체를 순회한다.
//		for(int i =0; i<fruits.length; i++ ) {
//			//확인!
////			if(fruits[i].equals(name)) {
//			if(name.equals(fruits[i])) {
//				//해당 조건문을 만족 한다는 것은....
//				System.out.println("판매완료");
//				fruits[i] = null; //사실은 지웠다면 앞으로 밀착도 좋아...
//				return;
//			}
//		}
////		return;
//		throw new FruitNotFoundException(name);
//	}
	//과일을 판매해보자
	public static boolean sell2(String name){
		for(int i =0; i<fruits.length; i++ ) {
			if(name.equals(fruits[i])) {
				System.out.println("판매완료");
				fruits[i] = null; //사실은 지웠다면 앞으로 밀착도 좋아...
				return true;
			}
		}
//		return false;
		throw new FruitNotFoundRuntimeException(name);
	}
	
}
