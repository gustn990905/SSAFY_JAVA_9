package exception_user;

public class FruitNotFoundRuntimeException extends RuntimeException{
	
	public FruitNotFoundRuntimeException(String name) {
		super(name+"에 해당하는 과일은 런타임시점에 없다.");
	}

}
